YUNG's Better Mineshafts for 1.18.2 no longer uses its own JSON files for creating custom mineshaft variants.
Minecraft 1.18.2 has introduced the ability to add custom structures via data pack,
so any mineshaft customization should be done by adding/modifying Better Mineshafts' configured_features via data pack.

If you need help, join the Discord!

discord.gg/rns3beq
